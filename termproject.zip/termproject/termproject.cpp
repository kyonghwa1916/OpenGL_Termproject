﻿#define _CRT_SECURE_NO_WARNINGS
#include <gl/glew.h>
#include <gl/freeglut.h>
#include <gl/freeglut_ext.h>
#include <iostream>
#include <vector>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string>
#include <algorithm>
#include <fstream>
#include <sstream>

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

// --- 파일 읽기 ---
char* filetobuf(const char* file) {
    FILE* fptr = fopen(file, "rb");
    if (!fptr) return NULL;
    fseek(fptr, 0, SEEK_END);
    long length = ftell(fptr);
    char* buf = (char*)malloc(length + 1);
    fseek(fptr, 0, SEEK_SET);
    fread(buf, length, 1, fptr);
    fclose(fptr);
    buf[length] = 0;
    return buf;
}

// --- 게임 상태 및 전역 변수 ---
enum GameState { MENU, PLAY, GAMEOVER, RANKING, NAME_INPUT };
GameState currentState = MENU;
int selectedMap = 1; // 1 or 2

// 랭킹 구조체
struct RankingEntry {
    int mapType;
    float time;
    std::string name;

    bool operator<(const RankingEntry& other) const {
        return time < other.time;
    }
};

std::vector<RankingEntry> rankingsMap1;
std::vector<RankingEntry> rankingsMap2;

// 이름 입력 관련
std::string currentInputName = "";
float recordedTime = 0.0f;

GLuint shaderProgramID;
GLuint vertexShader, fragmentShader;
GLuint bgVAO, bgVBO;
GLuint carVAO, carVBO;
GLuint lightVAO, lightVBO;
GLuint finishLineVAO, finishLineVBO;

GLuint roadTextureID, dirtTextureID;

GLuint modelLoc, viewLoc, projLoc;
GLuint useTextureLoc, isLightSourceLoc, viewPosLoc;

// 자동차 상태
float carX = 0.0f;
float carZ = 0.0f;
float carAngle = 0.0f;

// 타이머 관련
bool timerStarted = false;
int startTime = 0;
int elapsedTime = 0;
bool finishReached = false;

// 도로 설정
const float ROAD_WIDTH = 2.0f;       // 도로 전체 폭
const float SIDEWALK_WIDTH = 1.5f;   // 인도 폭
const float CAR_COLLISION_RADIUS = 0.5f; // 자동차 충돌 반경
const float TRACK_RADIUS = 80.0f; // 트랙의 반지름 (크기)
const int TRACK_SEGMENTS = 360;   // 원을 몇 개로 쪼갤지
int vertexCountRoad = 0;
int vertexCountSidewalk = 0;
const float FINISH_LINE_Z = -495.0f; // 피니시라인 위치

// 키 상태 추적
bool specialKeyStates[256] = { false };

// --- 수학 헬퍼 함수 ---
// Z 위치에 따른 도로의 중심 X 좌표를 반환 (곡선 도로 핵심 로직)
float getRoadCenterX(float z, int mapType) {
    if (mapType == 1) {
        // Map 1: 완만한 Sine 파형
        return sinf(z * 0.05f) * 10.0f;
    }
    else {
        // Map 2: 더 복잡하고 급격한 곡선
        return sinf(z * 0.1f) * 10.0f + cosf(z * 0.05f) * 5.0f;
    }
}

// 도로의 접선 각도 계산 (가로등 회전 등에 사용)
float getRoadAngle(float z, int mapType) {
    float delta = 0.1f;
    float x1 = getRoadCenterX(z, mapType);
    float x2 = getRoadCenterX(z - delta, mapType);
    return atan2f(x2 - x1, -delta); // -Z 방향이 진행 방향
}

void setIdentityMatrix(float* mat, int size) {
    for (int i = 0; i < size * size; ++i) mat[i] = 0.0f;
    for (int i = 0; i < size; ++i) mat[i * size + i] = 1.0f;
}
void makePerspectiveMatrix(float* mat, float fov, float aspect, float nearDist, float farDist) {
    setIdentityMatrix(mat, 4);
    float tanHalfFov = tanf(fov / 2.0f);
    mat[0] = 1.0f / (aspect * tanHalfFov);
    mat[5] = 1.0f / tanHalfFov;
    mat[10] = -(farDist + nearDist) / (farDist - nearDist);
    mat[11] = -1.0f;
    mat[14] = -(2.0f * farDist * nearDist) / (farDist - nearDist);
    mat[15] = 0.0f;
}
void setTranslationMatrix(float* mat, float x, float y, float z) {
    setIdentityMatrix(mat, 4);
    mat[12] = x; mat[13] = y; mat[14] = z;
}
void setRotationYMatrix(float* mat, float angle) {
    setIdentityMatrix(mat, 4);
    float c = cosf(angle);
    float s = sinf(angle);
    mat[0] = c;  mat[2] = s;
    mat[8] = -s; mat[10] = c;
}

// --- 랭킹 관련 함수 ---
void loadRankings() {
    rankingsMap1.clear();
    rankingsMap2.clear();

    std::ifstream file("rankings.txt");
    if (file.is_open()) {
        std::string line;
        while (std::getline(file, line)) {
            std::istringstream iss(line);
            int mapType;
            float time;
            std::string name;

            if (iss >> mapType >> time) {
                // 나머지 부분을 이름으로 읽기
                std::getline(iss, name);
                // 앞의 공백 제거
                if (!name.empty() && name[0] == ' ') {
                    name = name.substr(1);
                }

                RankingEntry entry;
                entry.mapType = mapType;
                entry.time = time;
                entry.name = name.empty() ? "Anonymous" : name;

                if (mapType == 1) {
                    rankingsMap1.push_back(entry);
                }
                else if (mapType == 2) {
                    rankingsMap2.push_back(entry);
                }
            }
        }
        file.close();
    }

    std::sort(rankingsMap1.begin(), rankingsMap1.end());
    std::sort(rankingsMap2.begin(), rankingsMap2.end());
}

void saveRanking(int mapType, float time, const std::string& name) {
    RankingEntry newEntry;
    newEntry.mapType = mapType;
    newEntry.time = time;
    newEntry.name = name.empty() ? "Anonymous" : name;

    if (mapType == 1) {
        rankingsMap1.push_back(newEntry);
        std::sort(rankingsMap1.begin(), rankingsMap1.end());
        if (rankingsMap1.size() > 5) {
            rankingsMap1.resize(5);
        }
    }
    else if (mapType == 2) {
        rankingsMap2.push_back(newEntry);
        std::sort(rankingsMap2.begin(), rankingsMap2.end());
        if (rankingsMap2.size() > 5) {
            rankingsMap2.resize(5);
        }
    }

    // 파일에 저장
    std::ofstream file("rankings.txt");
    if (file.is_open()) {
        for (const auto& entry : rankingsMap1) {
            file << entry.mapType << " " << entry.time << " " << entry.name << "\n";
        }
        for (const auto& entry : rankingsMap2) {
            file << entry.mapType << " " << entry.time << " " << entry.name << "\n";
        }
        file.close();
    }
}

// 텍스트 출력 함수
void drawString(const char* str, int x, int y) {
    glDisable(GL_LIGHTING);
    glDisable(GL_TEXTURE_2D);
    glUseProgram(0); // 고정 파이프라인 사용

    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();
    gluOrtho2D(0, 800, 0, 600);

    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glLoadIdentity();

    glColor3f(1.0f, 1.0f, 1.0f);
    glRasterPos2i(x, y);
    for (int i = 0; str[i] != '\0'; i++) {
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, str[i]);
    }

    glPopMatrix();
    glMatrixMode(GL_PROJECTION);
    glPopMatrix();
    glMatrixMode(GL_MODELVIEW);
    glEnable(GL_DEPTH_TEST);
}

// --- 텍스처 로드 ---
GLuint LoadTexture(const char* filename) {
    GLuint textureID;
    glGenTextures(1, &textureID);
    glBindTexture(GL_TEXTURE_2D, textureID);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    int width, height, nrChannels;
    stbi_set_flip_vertically_on_load(true);
    unsigned char* data = stbi_load(filename, &width, &height, &nrChannels, 0);
    if (data) {
        GLenum format = (nrChannels == 4) ? GL_RGBA : GL_RGB;
        glTexImage2D(GL_TEXTURE_2D, 0, format, width, height, 0, format, GL_UNSIGNED_BYTE, data);
        glGenerateMipmap(GL_TEXTURE_2D);
    }
    else {
        std::cout << "Texture Load Failed (Use Default Color): " << filename << std::endl;
    }
    stbi_image_free(data);
    return textureID;
}

// --- 쉐이더 컴파일 ---
void make_Shaders() {
    GLchar* vSrc = filetobuf("vertex.glsl");
    GLchar* fSrc = filetobuf("fragment.glsl");
    if (!vSrc || !fSrc) { std::cerr << "Shader file not found!" << std::endl; exit(1); }
    vertexShader = glCreateShader(GL_VERTEX_SHADER);
    fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(vertexShader, 1, &vSrc, NULL);
    glShaderSource(fragmentShader, 1, &fSrc, NULL);
    glCompileShader(vertexShader);
    glCompileShader(fragmentShader);
    shaderProgramID = glCreateProgram();
    glAttachShader(shaderProgramID, vertexShader);
    glAttachShader(shaderProgramID, fragmentShader);
    glLinkProgram(shaderProgramID);
    glDeleteShader(vertexShader);
    glDeleteShader(fragmentShader);
    free(vSrc); free(fSrc);
}

// --- 맵 생성 ---
void initMapBuffer(int mapType) {
    std::vector<float> v;
    float step = 2.0f;
    float startZ = 20.0f;

    // 도로 길이 -500으로 변경
    float endZ = -500.0f;

    float halfW = ROAD_WIDTH / 2.0f;

    // 높이 설정
    float roadY = -0.5f;
    float walkY = -0.3f;

    for (float z = startZ; z > endZ; z -= step) {
        float zNext = z - step;

        float cxCurrent = getRoadCenterX(z, mapType);
        float cxNext = getRoadCenterX(zNext, mapType);
        float ny = 1.0f;

        float v1 = -z * 0.1f;
        float v2 = -zNext * 0.1f;

        // --- [1] 도로 (Road) ---
        // Quad 1
        v.insert(v.end(), { cxCurrent - halfW, roadY, z,      1,1,1,  0.0f, v1,   0, ny, 0 });
        v.insert(v.end(), { cxCurrent + halfW, roadY, z,      1,1,1,  1.0f, v1,   0, ny, 0 });
        v.insert(v.end(), { cxNext + halfW,    roadY, zNext,  1,1,1,  1.0f, v2,   0, ny, 0 });
        // Quad 2
        v.insert(v.end(), { cxCurrent - halfW, roadY, z,      1,1,1,  0.0f, v1,   0, ny, 0 });
        v.insert(v.end(), { cxNext + halfW,    roadY, zNext,  1,1,1,  1.0f, v2,   0, ny, 0 });
        v.insert(v.end(), { cxNext - halfW,    roadY, zNext,  1,1,1,  0.0f, v2,   0, ny, 0 });
    }

    // 도로 정점 개수 저장
    vertexCountRoad = v.size() / 11;

    for (float z = startZ; z > endZ; z -= step) {
        float zNext = z - step;
        float cxCurrent = getRoadCenterX(z, mapType);
        float cxNext = getRoadCenterX(zNext, mapType);
        float ny = 1.0f;
        float v1 = -z * 0.1f;
        float v2 = -zNext * 0.1f;

        // --- [2] 왼쪽 인도 (Sidewalk Left) ---
        // Y값을 walkY(-0.3f)로 올림
        v.insert(v.end(), { cxCurrent - halfW - SIDEWALK_WIDTH, walkY, z,      1,1,1,  0.0f, v1,   0, ny, 0 });
        v.insert(v.end(), { cxCurrent - halfW,                  walkY, z,      1,1,1,  1.0f, v1,   0, ny, 0 });
        v.insert(v.end(), { cxNext - halfW,                     walkY, zNext,  1,1,1,  1.0f, v2,   0, ny, 0 });
        v.insert(v.end(), { cxCurrent - halfW - SIDEWALK_WIDTH, walkY, z,      1,1,1,  0.0f, v1,   0, ny, 0 });
        v.insert(v.end(), { cxNext - halfW,                     walkY, zNext,  1,1,1,  1.0f, v2,   0, ny, 0 });
        v.insert(v.end(), { cxNext - halfW - SIDEWALK_WIDTH,    walkY, zNext,  1,1,1,  0.0f, v2,   0, ny, 0 });

        // --- [3] 오른쪽 인도 (Sidewalk Right) ---
        v.insert(v.end(), { cxCurrent + halfW,                  walkY, z,      1,1,1,  0.0f, v1,   0, ny, 0 });
        v.insert(v.end(), { cxCurrent + halfW + SIDEWALK_WIDTH, walkY, z,      1,1,1,  1.0f, v1,   0, ny, 0 });
        v.insert(v.end(), { cxNext + halfW + SIDEWALK_WIDTH,    walkY, zNext,  1,1,1,  1.0f, v2,   0, ny, 0 });
        v.insert(v.end(), { cxCurrent + halfW,                  walkY, z,      1,1,1,  0.0f, v1,   0, ny, 0 });
        v.insert(v.end(), { cxNext + halfW + SIDEWALK_WIDTH,    walkY, zNext,  1,1,1,  1.0f, v2,   0, ny, 0 });
        v.insert(v.end(), { cxNext + halfW,                     walkY, zNext,  1,1,1,  0.0f, v2,   0, ny, 0 });

        // --- [4] 연석 (Curb) - 도로와 인도 사이 옆면 ---
        // 왼쪽 턱 옆면
        v.insert(v.end(), { cxCurrent - halfW, roadY, z,      0.5f,0.5f,0.5f,  0.0f, 0.0f,   1, 0, 0 });
        v.insert(v.end(), { cxCurrent - halfW, walkY, z,      0.5f,0.5f,0.5f,  0.0f, 0.0f,   1, 0, 0 });
        v.insert(v.end(), { cxNext - halfW,    walkY, zNext,  0.5f,0.5f,0.5f,  0.0f, 0.0f,   1, 0, 0 });
        v.insert(v.end(), { cxCurrent - halfW, roadY, z,      0.5f,0.5f,0.5f,  0.0f, 0.0f,   1, 0, 0 });
        v.insert(v.end(), { cxNext - halfW,    walkY, zNext,  0.5f,0.5f,0.5f,  0.0f, 0.0f,   1, 0, 0 });
        v.insert(v.end(), { cxNext - halfW,    roadY, zNext,  0.5f,0.5f,0.5f,  0.0f, 0.0f,   1, 0, 0 });

        // 오른쪽 턱 옆면
        v.insert(v.end(), { cxCurrent + halfW, roadY, z,      0.5f,0.5f,0.5f,  0.0f, 0.0f,  -1, 0, 0 });
        v.insert(v.end(), { cxCurrent + halfW, walkY, z,      0.5f,0.5f,0.5f,  0.0f, 0.0f,  -1, 0, 0 });
        v.insert(v.end(), { cxNext + halfW,    walkY, zNext,  0.5f,0.5f,0.5f,  0.0f, 0.0f,  -1, 0, 0 });
        v.insert(v.end(), { cxCurrent + halfW, roadY, z,      0.5f,0.5f,0.5f,  0.0f, 0.0f,  -1, 0, 0 });
        v.insert(v.end(), { cxNext + halfW,    walkY, zNext,  0.5f,0.5f,0.5f,  0.0f, 0.0f,  -1, 0, 0 });
        v.insert(v.end(), { cxNext + halfW,    roadY, zNext,  0.5f,0.5f,0.5f,  0.0f, 0.0f,  -1, 0, 0 });
    }

    // 전체 정점 개수에서 도로 정점 개수를 뺀 것이 나머지(인도+턱) 개수
    vertexCountSidewalk = (v.size() / 11) - vertexCountRoad;

    if (bgVAO == 0) glGenVertexArrays(1, &bgVAO);
    if (bgVBO == 0) glGenBuffers(1, &bgVBO);

    glBindVertexArray(bgVAO);
    glBindBuffer(GL_ARRAY_BUFFER, bgVBO);
    glBufferData(GL_ARRAY_BUFFER, v.size() * sizeof(float), v.data(), GL_STATIC_DRAW);

    int stride = 11 * sizeof(float);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, (void*)0); glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, stride, (void*)(3 * sizeof(float))); glEnableVertexAttribArray(1);
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, stride, (void*)(6 * sizeof(float))); glEnableVertexAttribArray(2);
    glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, stride, (void*)(8 * sizeof(float))); glEnableVertexAttribArray(3);
}

// 피니시라인 생성 함수
void initFinishLine(int mapType) {
    std::vector<float> v;

    float finishZ = FINISH_LINE_Z;
    float centerX = getRoadCenterX(finishZ, mapType);
    float halfW = ROAD_WIDTH / 2.0f;
    float finishY = -0.48f; // 도로보다 약간 위에 띄워서 그려짐

    // 노란색 피니시라인 (도로 전체 폭에 걸쳐서)
    float lineThickness = 0.5f; // 라인 두께

    // 왼쪽 -> 오른쪽, 앞 -> 뒤
    float x1 = centerX - halfW - 1.0f;
    float x2 = centerX + halfW + 1.0f;
    float z1 = finishZ - lineThickness / 2.0f;
    float z2 = finishZ + lineThickness / 2.0f;

    // 노란색 (1.0, 1.0, 0.0)
    float ny = 1.0f; // 법선 벡터 (위를 향함)

    // 첫 번째 삼각형
    v.insert(v.end(), { x1, finishY, z1,  1.0f, 1.0f, 0.0f,  0.0f, 0.0f,  0, ny, 0 });
    v.insert(v.end(), { x2, finishY, z1,  1.0f, 1.0f, 0.0f,  1.0f, 0.0f,  0, ny, 0 });
    v.insert(v.end(), { x2, finishY, z2,  1.0f, 1.0f, 0.0f,  1.0f, 1.0f,  0, ny, 0 });

    // 두 번째 삼각형
    v.insert(v.end(), { x1, finishY, z1,  1.0f, 1.0f, 0.0f,  0.0f, 0.0f,  0, ny, 0 });
    v.insert(v.end(), { x2, finishY, z2,  1.0f, 1.0f, 0.0f,  1.0f, 1.0f,  0, ny, 0 });
    v.insert(v.end(), { x1, finishY, z2,  1.0f, 1.0f, 0.0f,  0.0f, 1.0f,  0, ny, 0 });

    if (finishLineVAO == 0) glGenVertexArrays(1, &finishLineVAO);
    if (finishLineVBO == 0) glGenBuffers(1, &finishLineVBO);

    glBindVertexArray(finishLineVAO);
    glBindBuffer(GL_ARRAY_BUFFER, finishLineVBO);
    glBufferData(GL_ARRAY_BUFFER, v.size() * sizeof(float), v.data(), GL_STATIC_DRAW);

    int stride = 11 * sizeof(float);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, (void*)0); glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, stride, (void*)(3 * sizeof(float))); glEnableVertexAttribArray(1);
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, stride, (void*)(6 * sizeof(float))); glEnableVertexAttribArray(2);
    glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, stride, (void*)(8 * sizeof(float))); glEnableVertexAttribArray(3);
}

// 큐브/오브젝트 생성 함수
void initCubeObj(GLuint* vao, GLuint* vbo, bool isCar) {
    std::vector<float> v;

    // 원통 헬퍼
    auto addCylinder = [&](float x, float y, float z, float radius, float height, float r, float g, float b) {
        const int segments = 16; const float PI = 3.141592f;
        for (int i = 0; i < segments; ++i) {
            float angle1 = (float)i / segments * 2.0f * PI;
            float angle2 = (float)(i + 1) / segments * 2.0f * PI;
            float y1 = cosf(angle1) * radius; float z1 = sinf(angle1) * radius;
            float y2 = cosf(angle2) * radius; float z2 = sinf(angle2) * radius;
            float ny1 = cosf(angle1); float nz1 = sinf(angle1);
            float ny2 = cosf(angle2); float nz2 = sinf(angle2);

            v.insert(v.end(), { x - height / 2, y + y1, z + z1, r, g, b, 0, 0, 0, ny1, nz1 });
            v.insert(v.end(), { x + height / 2, y + y1, z + z1, r, g, b, 0, 0, 0, ny1, nz1 });
            v.insert(v.end(), { x + height / 2, y + y2, z + z2, r, g, b, 0, 0, 0, ny2, nz2 });
            v.insert(v.end(), { x - height / 2, y + y1, z + z1, r, g, b, 0, 0, 0, ny1, nz1 });
            v.insert(v.end(), { x + height / 2, y + y2, z + z2, r, g, b, 0, 0, 0, ny2, nz2 });
            v.insert(v.end(), { x - height / 2, y + y2, z + z2, r, g, b, 0, 0, 0, ny2, nz2 });
        }
        };

    // 면 생성 헬퍼
    auto addFace = [&](float x, float y, float z, float sx, float sy, float sz, float r, float g, float b) {
        float dx = sx / 2, dy = sy / 2, dz = sz / 2;
        float normals[6][3] = { {0,0,1}, {0,0,-1}, {0,1,0}, {0,-1,0}, {-1,0,0}, {1,0,0} };
        float pos[6][4][3] = {
            {{x - dx, y - dy, z + dz}, {x + dx, y - dy, z + dz}, {x + dx, y + dy, z + dz}, {x - dx, y + dy, z + dz}},
            {{x - dx, y - dy, z - dz}, {x + dx, y - dy, z - dz}, {x + dx, y + dy, z - dz}, {x - dx, y + dy, z - dz}},
            {{x - dx, y + dy, z + dz}, {x + dx, y + dy, z + dz}, {x + dx, y + dy, z - dz}, {x - dx, y + dy, z - dz}},
            {{x - dx, y - dy, z + dz}, {x + dx, y - dy, z + dz}, {x + dx, y - dy, z - dz}, {x - dx, y - dy, z - dz}},
            {{x - dx, y - dy, z - dz}, {x - dx, y - dy, z + dz}, {x - dx, y + dy, z + dz}, {x - dx, y + dy, z - dz}},
            {{x + dx, y - dy, z - dz}, {x + dx, y - dy, z + dz}, {x + dx, y + dy, z + dz}, {x + dx, y + dy, z - dz}}
        };
        int indices[] = { 0, 1, 2, 0, 2, 3 };
        for (int i = 0; i < 6; ++i) {
            for (int j = 0; j < 6; ++j) {
                int idx = indices[j];
                v.push_back(pos[i][idx][0]); v.push_back(pos[i][idx][1]); v.push_back(pos[i][idx][2]);
                v.push_back(r); v.push_back(g); v.push_back(b);
                v.push_back(0.0f); v.push_back(0.0f);
                v.push_back(normals[i][0]); v.push_back(normals[i][1]); v.push_back(normals[i][2]);
            }
        }
        };

    if (isCar) {
        addFace(0.0f, 0.0f, 0.0f, 0.8f, 0.25f, 1.2f, 0.8f, 0.1f, 0.1f);
        addFace(0.0f, 0.25f, 0.15f, 0.6f, 0.3f, 0.6f, 0.6f, 0.05f, 0.05f);
        addFace(0.0f, 0.05f, -0.5f, 0.6f, 0.15f, 0.4f, 0.9f, 0.15f, 0.15f);
        float wR = 0.15f, wW = 0.12f, wX = 0.45f, wZ = 0.4f;
        addCylinder(-wX, -0.125f + wR, -wZ, wR, wW, 0.1f, 0.1f, 0.1f);
        addCylinder(wX, -0.125f + wR, -wZ, wR, wW, 0.1f, 0.1f, 0.1f);
        addCylinder(-wX, -0.125f + wR, wZ, wR, wW, 0.1f, 0.1f, 0.1f);
        addCylinder(wX, -0.125f + wR, wZ, wR, wW, 0.1f, 0.1f, 0.1f);
        addFace(0.0f, 0.3f, -0.15f, 0.55f, 0.2f, 0.15f, 0.3f, 0.5f, 0.7f);
        addFace(-0.25f, 0.0f, -0.62f, 0.12f, 0.08f, 0.04f, 1.0f, 1.0f, 0.6f);
        addFace(0.25f, 0.0f, -0.62f, 0.12f, 0.08f, 0.04f, 1.0f, 1.0f, 0.6f);
    }
    else { // 가로등
        addFace(0.0f, 1.5f, 0.0f, 0.2f, 3.0f, 0.2f, 0.5f, 0.5f, 0.5f);
        addFace(0.6f, 2.9f, 0.0f, 1.2f, 0.15f, 0.15f, 0.5f, 0.5f, 0.5f);
        addFace(1.1f, 2.7f, 0.0f, 0.3f, 0.3f, 0.3f, 1.0f, 1.0f, 0.5f);
    }

    glGenVertexArrays(1, vao);
    glGenBuffers(1, vbo);
    glBindVertexArray(*vao);
    glBindBuffer(GL_ARRAY_BUFFER, *vbo);
    glBufferData(GL_ARRAY_BUFFER, v.size() * sizeof(float), v.data(), GL_STATIC_DRAW);
    int stride = 11 * sizeof(float);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, (void*)0); glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, stride, (void*)(3 * sizeof(float))); glEnableVertexAttribArray(1);
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, stride, (void*)(6 * sizeof(float))); glEnableVertexAttribArray(2);
    glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, stride, (void*)(8 * sizeof(float))); glEnableVertexAttribArray(3);
}

// --- 게임 초기화 ---
void initGame(int map) {
    selectedMap = map;
    carX = getRoadCenterX(0.0f, map); // 도로 중앙에서 시작
    carZ = 0.0f;
    carAngle = 0.0f;
    timerStarted = false;
    startTime = 0;
    elapsedTime = 0;
    finishReached = false;
    initMapBuffer(map);
    initFinishLine(map); // 피니시라인 생성
    currentState = PLAY;
}

// 키 상태에 따라 자동차 업데이트 및 충돌 체크
void updateCar() {
    if (currentState != PLAY) return;

    float speed = 0.3f;
    float rotSpeed = 0.02f;

    float forwardX = sinf(carAngle);
    float forwardZ = -cosf(carAngle);

    // 방향키가 입력되면 타이머 시작
    if (!timerStarted && (specialKeyStates[GLUT_KEY_UP] || specialKeyStates[GLUT_KEY_DOWN] ||
                          specialKeyStates[GLUT_KEY_LEFT] || specialKeyStates[GLUT_KEY_RIGHT])) {
        timerStarted = true;
        startTime = glutGet(GLUT_ELAPSED_TIME);
    }

    if (specialKeyStates[GLUT_KEY_UP]) {
        carX += speed * forwardX;
        carZ += speed * forwardZ;
    }
    if (specialKeyStates[GLUT_KEY_DOWN]) {
        carX -= speed * forwardX;
        carZ -= speed * forwardZ;
    }
    if (specialKeyStates[GLUT_KEY_LEFT]) {
        carAngle -= rotSpeed;
    }
    if (specialKeyStates[GLUT_KEY_RIGHT]) {
        carAngle += rotSpeed;
    }

    // 타이머가 시작되었고 아직 피니시라인에 도달하지 않았다면 시간 업데이트
    if (timerStarted && !finishReached) {
        elapsedTime = glutGet(GLUT_ELAPSED_TIME) - startTime;
    }

    // 피니시라인 도달 체크
    if (!finishReached && carZ <= FINISH_LINE_Z) {
        finishReached = true;
        elapsedTime = glutGet(GLUT_ELAPSED_TIME) - startTime;

        // 이름 입력 화면으로 전환
        recordedTime = elapsedTime / 1000.0f;
        currentInputName = "";
        currentState = NAME_INPUT;
    }

    // --- 충돌 체크 (Collision Detection) ---
    float roadCenter = getRoadCenterX(carZ, selectedMap);
    float limit = (ROAD_WIDTH / 2.0f) - CAR_COLLISION_RADIUS;

    // 도로 중심과의 거리 계산
    if (abs(carX - roadCenter) > limit) {
        // 도로를 벗어남 -> 인도 충돌
        currentState = GAMEOVER;
    }
}

GLvoid drawScene() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    if (currentState == MENU) {
        glClearColor(0.1f, 0.1f, 0.1f, 1.0f);
        drawString("=== Select Map ===", 320, 350);
        drawString("Press '1' for Map 1 (Gentle Curve)", 250, 300);
        drawString("Press '2' for Map 2 (Complex Curve)", 250, 270);
        drawString("Press 'R' to View Rankings", 280, 240);
        glutSwapBuffers();
        return;
    }
    else if (currentState == NAME_INPUT) {
        glClearColor(0.1f, 0.15f, 0.1f, 1.0f);
        drawString("=== FINISH! ===", 330, 400);

        char timeStr[64];
        sprintf(timeStr, "Your Time: %.2f sec", recordedTime);
        drawString(timeStr, 310, 350);

        drawString("Enter Your Name:", 300, 300);

        // 입력된 이름 표시 (커서 포함)
        std::string displayName = currentInputName + "_";
        drawString(displayName.c_str(), 320, 260);

        drawString("Press ENTER to save", 290, 200);
        drawString("Max 10 characters", 300, 170);

        glutSwapBuffers();
        return;
    }
    else if (currentState == RANKING) {
        glClearColor(0.1f, 0.1f, 0.15f, 1.0f);
        drawString("=== RANKINGS ===", 330, 550);

        // Map 1 Rankings
        drawString("Map 1 - Gentle Curve", 100, 500);
        int yPos = 460;
        for (size_t i = 0; i < rankingsMap1.size(); i++) {
            char rankStr[128];
            sprintf(rankStr, "%d. %-12s %.2f sec", (int)(i + 1), rankingsMap1[i].name.c_str(), rankingsMap1[i].time);
            drawString(rankStr, 100, yPos);
            yPos -= 30;
        }

        // Map 2 Rankings
        drawString("Map 2 - Complex Curve", 450, 500);
        yPos = 460;
        for (size_t i = 0; i < rankingsMap2.size(); i++) {
            char rankStr[128];
            sprintf(rankStr, "%d. %-12s %.2f sec", (int)(i + 1), rankingsMap2[i].name.c_str(), rankingsMap2[i].time);
            drawString(rankStr, 450, yPos);
            yPos -= 30;
        }

        drawString("Press 'ESC' to return to Menu", 270, 50);
        glutSwapBuffers();
        return;
    }
    else if (currentState == GAMEOVER) {
        glClearColor(0.3f, 0.0f, 0.0f, 1.0f);
    }
    else {
        glClearColor(0.05f, 0.05f, 0.1f, 1.0f);
    }

    glUseProgram(shaderProgramID);

    // --- [1] 카메라 설정 ---
    // 자동차 뒤쪽에서 바라보는 좌표 계산
    float camDist = 10.0f;
    float camHeight = 5.0f;
    float eyeX = carX - camDist * sinf(carAngle);
    float eyeZ = carZ - camDist * (-cosf(carAngle)); 

    float eyeY = camHeight;
    float targetX = carX;
    float targetY = 0.0f;
    float targetZ = carZ;

    glUniform3f(viewPosLoc, eyeX, eyeY, eyeZ);

    // gluLookAt을 사용해 View Matrix 생성 후 Shader로 전송
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glLoadIdentity();
    gluLookAt(eyeX, eyeY, eyeZ, targetX, targetY, targetZ, 0, 1, 0);

    float view[16];
    glGetFloatv(GL_MODELVIEW_MATRIX, view); // 계산된 행렬 가져오기
    glPopMatrix(); // 스택 복구

    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, view);

    // Projection Matrix
    float projection[16];
    makePerspectiveMatrix(projection, 3.141592f / 4.0f, 800.0f / 600.0f, 0.1f, 300.0f);
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, projection);

    // --- [조명 설정] ---
    int centerIdx = (int)(abs(carZ) / 20.0f);
    int lightCount = 0;
    char uniformName[64];
    for (int i = centerIdx - 1; i <= centerIdx + 2; ++i) {
        if (lightCount >= 4) break;
        float lightZ = -(float)i * 20.0f;
        float lightX = getRoadCenterX(lightZ, selectedMap) - 2.5f + 1.1f;
        sprintf(uniformName, "pointLights[%d].position", lightCount);
        glUniform3f(glGetUniformLocation(shaderProgramID, uniformName), lightX, 2.7f, lightZ);
        sprintf(uniformName, "pointLights[%d].color", lightCount);
        glUniform3f(glGetUniformLocation(shaderProgramID, uniformName), 1.0f, 0.9f, 0.6f);
        sprintf(uniformName, "pointLights[%d].constant", lightCount);
        glUniform1f(glGetUniformLocation(shaderProgramID, uniformName), 1.0f);
        sprintf(uniformName, "pointLights[%d].linear", lightCount);
        glUniform1f(glGetUniformLocation(shaderProgramID, uniformName), 0.09f);
        sprintf(uniformName, "pointLights[%d].quadratic", lightCount);
        glUniform1f(glGetUniformLocation(shaderProgramID, uniformName), 0.032f);
        lightCount++;
    }

    float model[16];
    setIdentityMatrix(model, 4);
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, model);

    // --- [2] 배경 그리기 ---
    glUniform1i(useTextureLoc, 1);
    glUniform1i(isLightSourceLoc, 0);

    glBindVertexArray(bgVAO);

    // 1) 도로 그리기 
    glBindTexture(GL_TEXTURE_2D, roadTextureID);
    glDrawArrays(GL_TRIANGLES, 0, vertexCountRoad);

    // 2) 인도 그리기
    glBindTexture(GL_TEXTURE_2D, dirtTextureID);
    glDrawArrays(GL_TRIANGLES, vertexCountRoad, vertexCountSidewalk);

    // 2.5) 피니시라인 그리기
    glUniform1i(useTextureLoc, 0); // 텍스처 사용 안 함
    glBindVertexArray(finishLineVAO);
    setIdentityMatrix(model, 4);
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, model);
    glDrawArrays(GL_TRIANGLES, 0, 6); // 6개의 정점 (2개의 삼각형)

    // --- [3] 가로등 ---
    glUniform1i(useTextureLoc, 0);
    glBindVertexArray(lightVAO);
    for (float z = 20.0f; z > -500.0f; z -= 20.0f) {

        float cx = getRoadCenterX(z, selectedMap);
        float angle = getRoadAngle(z, selectedMap);
        float tx = cx - (ROAD_WIDTH / 2.0f) - 0.5f;

        // 기둥
        glUniform1i(isLightSourceLoc, 0);
        setTranslationMatrix(model, tx, -0.5f, z);
        glUniformMatrix4fv(modelLoc, 1, GL_FALSE, model);
        glDrawArrays(GL_TRIANGLES, 0, 72);

        // 전구
        glUniform1i(isLightSourceLoc, 1);
        setTranslationMatrix(model, tx, -0.5f, z);
        glUniformMatrix4fv(modelLoc, 1, GL_FALSE, model);
        glDrawArrays(GL_TRIANGLES, 72, 36);
    }

    // --- [4] 자동차 (기존 유지) ---
    glUniform1i(isLightSourceLoc, 0);
    float rot[16];
    setRotationYMatrix(rot, carAngle);
    rot[12] = carX; rot[13] = -0.25f; rot[14] = carZ;
    for (int i = 0; i < 16; ++i) model[i] = rot[i];
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, model);
    glBindVertexArray(carVAO);
    glDrawArrays(GL_TRIANGLES, 0, 984);

    // 타이머 표시
    if (currentState == PLAY && timerStarted) {
        char timeStr[64];
        float seconds = elapsedTime / 1000.0f;
        sprintf(timeStr, "Time: %.2f sec", seconds);
        drawString(timeStr, 20, 560);

        if (finishReached) {
            drawString("FINISH!", 350, 300);
            char finalTimeStr[64];
            sprintf(finalTimeStr, "Final Time: %.2f sec", seconds);
            drawString(finalTimeStr, 310, 270);
        }
    }

    if (currentState == GAMEOVER) {
        drawString("GAME OVER", 350, 300);
        drawString("Press 'R' to Restart", 320, 270);

        if (timerStarted) {
            char timeStr[64];
            float seconds = elapsedTime / 1000.0f;
            sprintf(timeStr, "Time: %.2f sec", seconds);
            drawString(timeStr, 320, 240);
        }
    }

    glutSwapBuffers();
}

GLvoid Reshape(int w, int h) { glViewport(0, 0, w, h); }
void Keyboard(unsigned char key, int x, int y) {
    if (key == 'q' || key == 'Q') exit(0);

    if (currentState == MENU) {
        if (key == '1') initGame(1);
        if (key == '2') initGame(2);
        if (key == 'r' || key == 'R') {
            loadRankings();
            currentState = RANKING;
        }
    }
    else if (currentState == NAME_INPUT) {
        if (key == 13) { // ENTER key
            // 이름 저장하고 메뉴로
            saveRanking(selectedMap, recordedTime, currentInputName);
            loadRankings(); // 랭킹 다시 로드
            currentState = MENU;
        }
        else if (key == 8) { // BACKSPACE key
            if (!currentInputName.empty()) {
                currentInputName.pop_back();
            }
        }
        else if (key >= 32 && key <= 126) { // 출력 가능한 ASCII 문자
            if (currentInputName.length() < 10) {
                currentInputName += key;
            }
        }
    }
    else if (currentState == RANKING) {
        if (key == 27) { // ESC key
            currentState = MENU;
        }
    }
    else if (currentState == GAMEOVER) {
        if (key == 'r' || key == 'R') {
            currentState = MENU;
        }
    }
}

void SpecialKeyboard(int key, int x, int y) { specialKeyStates[key] = true; }
void SpecialKeyboardUp(int key, int x, int y) { specialKeyStates[key] = false; }

void Timer(int value) {
    updateCar();
    glutPostRedisplay();
    glutTimerFunc(16, Timer, 0);
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH);
    glutInitWindowPosition(100, 100);
    glutInitWindowSize(800, 600);
    glutCreateWindow("Curved Road Racing");

    glewExperimental = GL_TRUE;
    if (glewInit() != GLEW_OK) exit(EXIT_FAILURE);
    glEnable(GL_DEPTH_TEST);

    // 랭킹 로드
    loadRankings();

    make_Shaders();

    modelLoc = glGetUniformLocation(shaderProgramID, "model");
    viewLoc = glGetUniformLocation(shaderProgramID, "view");
    projLoc = glGetUniformLocation(shaderProgramID, "projection");
    useTextureLoc = glGetUniformLocation(shaderProgramID, "useTexture");
    isLightSourceLoc = glGetUniformLocation(shaderProgramID, "isLightSource");
    viewPosLoc = glGetUniformLocation(shaderProgramID, "viewPos");

    roadTextureID = LoadTexture("road.png"); 
    dirtTextureID = LoadTexture("dirt.png"); 

    // 기본 버퍼 초기화 (메뉴 화면용 더미 데이터 혹은 초기값)
    initCubeObj(&lightVAO, &lightVBO, false);
    initCubeObj(&carVAO, &carVBO, true);

    glutDisplayFunc(drawScene);
    glutReshapeFunc(Reshape);
    glutKeyboardFunc(Keyboard);
    glutSpecialFunc(SpecialKeyboard);
    glutSpecialUpFunc(SpecialKeyboardUp);
    glutTimerFunc(16, Timer, 0);

    glutMainLoop();
    return 0;
}